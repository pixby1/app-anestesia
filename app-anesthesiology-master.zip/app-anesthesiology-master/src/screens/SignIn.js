// Packages
import React from 'react';
import { WebView } from 'react-native-webview';

const SignIn = () => {
  return <WebView source={{ uri: 'https://registry.anestesiaclasa.org/' }} />;
};
export default SignIn;
